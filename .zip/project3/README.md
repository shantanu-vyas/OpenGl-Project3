Things to do:
- light object and its control
- shadow models
- camera limitations (x/y axis rotation beyond pi/2)
